<!DOCTYPE html>
<html <?php language_attributes(); ?> >

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>

  <?php wp_head(); ?>

 
  

</head>

<body>

  <header class="header">
    <div class="container">
      <div class="header__top">
        <a class="logo" href="#">
            <img src="<?php bloginfo('template_url'); ?>/assets/images/logo.png" alt="logo" style="width:20%">
        </a>
        <a class="phone" href="tel:+79113754671"> +7 911 375 46 71 </a>
      </div>
      <div class="header__content">
        <h1 data-wow-delay=".5s" class="header__title wow animate__fadeInLeft">
          фотостудия
        </h1>
        <h2 data-wow-delay="1s" class="header__subtitle wow animate__fadeInLeft">
          закажи фотосессию своим близким
        </h2>
        <p data-wow-delay="1.5s" class="header__text wow animate__fadeInLeft">
          Современные фотостудии профессионального уровня из Санкт-Петербурга для реализации проектов любой сложности.
          У нас уютно, комфортно и самое лучшее расположение в городе.
        </p>
        <a class="button" href="#">ЗАКАЗАТЬ ФОТОСЕССИЮ</a>
        <div class="social header__social">
          <a class="social__link" href="#">
            <svg class="test" width="26" height="26">
              <use xlink:href="<?php bloginfo('template_url'); ?>/assets/images/icon/sprite.svg#instagram"></use>
            </svg>
          </a>
          <a class="social__link" href="#">
            <svg width="25" height="19">
              <use xlink:href="<?php bloginfo('template_url'); ?>/assets/images/icon/sprite.svg#telegram"></use>
            </svg>
          </a>
          <a class="social__link" href="#">
            <svg width="26" height="26">
              <use xlink:href="<?php bloginfo('template_url'); ?>/assets/images/icon/sprite.svg#whatsapp"></use>
            </svg>
          </a>
          <a class="social__link" href="#">
            <svg width="14" height="25">
              <use xlink:href="<?php bloginfo('template_url'); ?>/assets/images/icon/sprite.svg#facebook"></use>
            </svg>
          </a>
        </div>
      </div>
    </div>
  </header>