<?php
/*
Template Name: home
*/
?>


<?php get_header(); ?>

  <section class="services">
    <div class="container">
      <h2 class="title">О НАС</h2>
      <div class="services__inner">
        <div class="services__content">
          <div class="services__content-box">
            <h6 class="services__content-title">
              Почему мы?
            </h6>
            <div class="services__content-textbox">
              <p class="services__content-text">
                Мы - высококлассная современная фотостудия в центре Санкт - Петербурга.
                В State вы можете арендовать съёмочный зал или заказать фотосессию с нашим фотографом.
              <p class="services__content-text">
                Наши преимущества – профессиональная команда, 3 просторных зала, широкий выбор высококлассного
                светового оборудования, огромная и постоянно пополняемая коллекция фонов, стильный минимализм в
                интерьере, чистота и приятная атмосфера.
              </p>
              </p>
            </div>
          </div>
          <div class="services__content-box">
            <h6 class="services__content-title">
              Приемлемая цена
            </h6>
            <div class="services__content-textbox">
              <p class="services__content-text">
                Фотосъёмка и видеосъёмка в Нижнем Новгороде по цене, которая была бы для вас приемлема, проводится
                профессионалами студии «100% ART».
                Стоимость определяется различными параметрами: собираетесь ли вы использовать услуги визажиста или
                украшать место съёмок предоставляемыми нами декорациями, будет ли процесс длиться час или весь день и
                т. д.
                Расценки указаны в разделе «цены».
              </p>
            </div>
            <a class="button button--decor" href="#">ЗАКАЗАТЬ ФОТОСЕССИЮ</a>
          </div>
        </div>
      </div>
    </div>
  </section>


  <section class="benefits">
    <div class="container">
      <div class="benefits__inner">
        <img data-wow-delay="2s" class="benefits__images wow animate__fadeInUp"
          src="images\galeri\36d534367fdc3384cc2d5e02d23c1b81.jpg" alt="portret">
        <div class="benefits__content">
        </div>
      </div>
    </div>
  </section>


  <section class="carousel">
    <div class="container">
      <h2 class="title">
        ИНТЕРЬЕРНЫЕ СТУДИИ
      </h2>
      <h3 class="title">
        ЗАЛ A
      </h3>
      <div class="carousel__inner">

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/1.1.1.jpg" alt="">
            <h4 class="carousel__item-title">Французский завтрак</h4>
            <p class="carousel__item-text">Стоимость 1520 руб/час </p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/1.1.2.jpg" alt="">
            <h4 class="carousel__item-title">Французский завтрак</h4>
            <p class="carousel__item-text">Стоимость 1520 руб/час</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/1.1.3.jpg" alt="">
            <h4 class="carousel__item-title">Французский завтрак</h4>
            <p class="carousel__item-text">Стоимость 1520 руб/час</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/1.1.4.jpg" alt="">
            <h4 class="carousel__item-title">Французский завтрак</h4>
            <p class="carousel__item-text">Стоимость 1520 руб/час</p>
          </div>
        </div>

      </div>

      <h3 class="title">
        ЗАЛ В
      </h3>
      <div class="carousel__inner">

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/2.1.jpg" alt="">
            <h4 class="carousel__item-title">Гостинная</h4>
            <p class="carousel__item-text">Стоимость 980 руб/час </p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/2.2.jpg" alt="">
            <h4 class="carousel__item-title">Гостинная</h4>
            <p class="carousel__item-text">Стоимость 980 руб/час</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/2.3.jpg" alt="">
            <h4 class="carousel__item-title">Гостинная</h4>
            <p class="carousel__item-text">Стоимость 980 руб/час</p>
          </div>
        </div>
        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/2.4.jpg" alt="">
            <h4 class="carousel__item-title">Гостинная</h4>
            <p class="carousel__item-text">Стоимость 980 руб/час</p>
          </div>
        </div>
      </div>

      <h3 class="title">
        ЗАЛ С
      </h3>
      <div class="carousel__inner">

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/3.1.jpg" alt="">
            <h4 class="carousel__item-title">Minimalism</h4>
            <p class="carousel__item-text">Стоимость 760 руб/час </p>
          </div>
        </div>
        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/3.2.jpg" alt="">
            <h4 class="carousel__item-title">Minimalism</h4>
            <p class="carousel__item-text">Стоимость 760 руб/час</p>
          </div>
        </div>
        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/3.3.jpg" alt="">
            <h4 class="carousel__item-title">Minimalism</h4>
            <p class="carousel__item-text">Стоимость 760 руб/час</p>
          </div>
        </div>
        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/3.4.jpg" alt="">
            <h4 class="carousel__item-title">Minimalism</h4>
            <p class="carousel__item-text">Стоимость 760 руб/час</p>
          </div>
        </div>
      </div>

      <h3 class="title">
        ГРИМЕРНАЯ
      </h3>
      <div class="carousel__inner">

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/4.1.jpg" alt="">
            <h4 class="carousel__item-title">MAKE-UP 1</h4>
            <p class="carousel__item-text">Бесплатно за час до съемки</p>
          </div>
        </div>
        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/4.2.jpg" alt="">
            <h4 class="carousel__item-title">MAKE-UP 1</h4>
            <p class="carousel__item-text">Бесплатно за час до съемки</p>
          </div>
        </div>
        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/4.3.jpg" alt="">
            <h4 class="carousel__item-title">MAKE-UP 2</h4>
            <p class="carousel__item-text">Бесплатно за час до съемки</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/studio/4.4.jpg" alt="">
            <h4 class="carousel__item-title">MAKE-UP 2</h4>
            <p class="carousel__item-text">Бесплатно за час до съемки</p>
          </div>
        </div>

      </div>


  </section>


  <section class="carousel">
    <div class="container">
      <h2 class="title">
        ГАЛЕРЕЯ РАБОТ
      </h2>
      <div class="carousel__inner">

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/b545049b122c0e85ddcd98d186ac1075.jpg" alt="">
            <h4 class="carousel__item-title">На природе</h4>
            <p class="carousel__item-text">Стоимость услуги 2500 руб</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/ed54e10c6b876187ac40290ef2d80273.jpg" alt="">
            <h4 class="carousel__item-title">Групповые фото</h4>
            <p class="carousel__item-text">Стоимость услуги 2800 руб</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/b545049b122c0e85ddcd98d186ac1075.jpg" alt="">
            <h4 class="carousel__item-title">На природе</h4>
            <p class="carousel__item-text">Стоимость услуги 2500 руб</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/1396c6a9572bbd8d5534488e3ed801a8.jpg" alt="">
            <h4 class="carousel__item-title">Портреты</h4>
            <p class="carousel__item-text">Стоимость услуги 2800 руб</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/b545049b122c0e85ddcd98d186ac1075.jpg" alt="">
            <h4 class="carousel__item-title">На природе</h4>
            <p class="carousel__item-text">Стоимость услуги 2500 руб</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/ed54e10c6b876187ac40290ef2d80273.jpg" alt="">
            <h4 class="carousel__item-title">Групповые фото</h4>
            <p class="carousel__item-text">Стоимость услуги 2800 руб</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/b545049b122c0e85ddcd98d186ac1075.jpg" alt="">
            <h4 class="carousel__item-title">На природе</h4>
            <p class="carousel__item-text">Стоимость услуги 2500 руб</p>
          </div>
        </div>

        <div class="carousel__item">
          <div class="carousel__item-box">
            <img class="carousel__item-img" src="<?php bloginfo('template_url'); ?>/assets/images/galeri/1396c6a9572bbd8d5534488e3ed801a8.jpg" alt="">
            <h4 class="carousel__item-title">Портреты</h4>
            <p class="carousel__item-text">Стоимость услуги 2800 руб</p>
          </div>
        </div>

      </div>
    </div>
  </section>


  <section class="contacts">
    <div class="container">
      <div class="contacts__inner">
        <div class="contacts__info">
          <h2 class="title">
            КОНТАКТЫ
          </h2>
          <ul class="contacts__list">
            <li class="contacts__item">
              <p class="contacts__item-title">Адрес</p>
              <p class="contacts__item-text">
                СПб <br>
                Полюстровский проспект, 47
              </p>
            </li>
            <li class="contacts__item">
              <p class="contacts__item-title">Время работы</p>
              <p class="contacts__item-text">
                Пн-Сб: с 09:00 до 21:00, <br>
                Вс: с 10:00 до 20:00
              </p>
            </li>
            <li class="contacts__item">
              <p class="contacts__item-title">Телефон</p>
              <p class="contacts__item-text">
                +7 911 375 46 71
              </p>
            </li>
          </ul>
        </div>
        <form class="contacts__form">
          <h2 class="title contacts__title">Оставить заявку</h2>
          <input class="contacts__input" type="text" placeholder="Ваше ФИО">
          <input class="contacts__input" type="tel" placeholder="Ваш номер телефона">
          <input class="contacts__input" type="text" placeholder="Какое мероприятие вы хотите заказать?">
          <input class="contacts__input" type="e-mail" placeholder="Электронная почта">
          <input class="contacts__input" type="date" placeholder="Предполагаемая дата">
          <button class="contacts__btn button" type="submit">Отправить заявку</button>
        </form>
      </div>
    </div>
  </section>

<?php get_footer(); ?>